import { useState, useCallback, useEffect } from 'react';
import { IconButton, Fade, Divider } from '@mui/material';
import ArrowBackIcon from '@mui/icons-material/ArrowBack';
import LockOpenIcon from '@mui/icons-material/LockOpen';
import { Box, Button, Container, Grid, Paper, TextField, Typography, MenuItem, Select, FormControl, InputLabel, CircularProgress, Tooltip, InputAdornment, Alert, Stack, Chip } from '@mui/material';
import AutoAwesomeIcon from '@mui/icons-material/AutoAwesome';
import HelpOutlineIcon from '@mui/icons-material/HelpOutline';
import WarningAmberIcon from '@mui/icons-material/WarningAmber';
import MyLocationIcon from '@mui/icons-material/MyLocation';
import GppGoodIcon from '@mui/icons-material/GppGood';
import ContentPasteIcon from '@mui/icons-material/ContentPaste';
import RefreshIcon from '@mui/icons-material/Refresh';
import { MapContainer, TileLayer, Marker, useMapEvents, useMap, Circle } from 'react-leaflet';
import L from 'leaflet';
import { applyToken } from '../services/auth';
import { api } from '../services/api';
import { useNavigate, Link } from 'react-router-dom';
import 'leaflet/dist/leaflet.css';
import { PriceTruthGap } from '../components/PriceTruthGap';

// Fix for Leaflet default icon issues in React
import icon from 'leaflet/dist/images/marker-icon.png';
import iconShadow from 'leaflet/dist/images/marker-shadow.png';
let DefaultIcon = L.icon({
    iconUrl: icon,
    shadowUrl: iconShadow,
    iconSize: [25, 41],
    iconAnchor: [12, 41]
});
L.Marker.prototype.options.icon = DefaultIcon;

// Nairobi Neighborhoods for Search Simulation
const NAIROBI_NEIGHBORHOODS = [
  { name: 'Westlands', lat: -1.2675, lng: 36.8120 },
  { name: 'Kilimani', lat: -1.2901, lng: 36.7830 },
  { name: 'Kasarani', lat: -1.2201, lng: 36.8961 },
  { name: 'Karen', lat: -1.3200, lng: 36.7000 },
  { name: 'Eastlands', lat: -1.2858, lng: 36.8833 },
  { name: 'Nairobi CBD', lat: -1.286389, lng: 36.817223 },
  { name: 'Langata', lat: -1.3333, lng: 36.7667 },
  { name: 'Embakasi', lat: -1.3000, lng: 36.9167 },
];

function LocationPicker({ onLocationSelect, position, setPosition, privacyMode }: { onLocationSelect: (loc: { lat: number, lng: number }) => void, position: any, setPosition: any, privacyMode: boolean }) {
  const map = useMap();
  
  useMapEvents({
    click(e) {
      setPosition(e.latlng);
      onLocationSelect({ lat: e.latlng.lat, lng: e.latlng.lng });
    }
  });

  useEffect(() => {
    if (position) {
      map.flyTo(position, map.getZoom());
    }
  }, [position, map]);

  return position ? (
    <>
      {privacyMode ? (
        <Circle 
          center={[position.lat, position.lng]} 
          radius={500} 
          pathOptions={{ color: '#1b5e20', fillColor: '#1b5e20', fillOpacity: 0.2 }} 
        />
      ) : (
        <Marker position={[position.lat, position.lng]} />
      )}
    </>
  ) : null;
}

// Plain Language Description Generator
const generateAIDescription = (title: string, category: string, marketData?: any) => {
  const templates: Record<string, string[]> = {
    'Dairy': [
      `Pure, fresh ${title} from healthy local cows. Clean, safe, and delivered cold to your neighborhood.`,
      `Farm-fresh ${title}. We follow strict hygiene rules to make sure you get the best quality every day.`,
    ],
    'Vegetables': [
      `Freshly harvested ${title}. Grown locally using organic methods. Picked this morning for the best taste and nutrition.`,
      `Quality ${title} from our local garden. We don't use harsh chemicals, and we deliver fast to keep it crisp.`,
    ],
    'Fruits': [
      `Sweet and juicy ${title}. Ripened naturally on the tree and brought straight to the city. Perfect for healthy snacks.`,
      `Local ${title} full of flavor. We handle our fruit with care so it reaches you in perfect condition.`,
    ],
    'Grains': [
      `High-quality ${title} harvested from our recent crop. Cleaned, dried, and ready for your kitchen.`,
      `Local ${title} grown with care. Great for long-term storage or immediate use in your favorite meals.`,
    ],
    'Meat': [
      `Quality ${title} from locally raised livestock. Processed with care and delivered fresh to your neighborhood.`,
      `Premium ${title} sourced directly from trusted local farmers. Safe, clean, and nutritious for your family.`,
    ],
    'Honey': [
      `Pure, raw ${title} harvested from local bee colonies. Natural, unprocessed, and full of health benefits.`,
      `Local ${title} with a unique floral flavor. Perfect for sweetening your drinks or as a healthy spread.`,
    ],
    'Other': [
      `Fresh ${title} produced with care on our local farm. Quality you can trust, delivered directly to you.`,
      `High-quality ${title} from a verified local producer. Simple, honest food for Kenya's future.`,
    ]
  };
  const categoryTemplates = templates[category] || templates['Other'];
  return categoryTemplates[Math.floor(Math.random() * categoryTemplates.length)];
};

import { useProducts } from '../app/ProductContext';

interface MarketInsights {
  recommendedPrice: number;
  disruption: boolean;
}

const titleToSlug = (title: string) => title.toLowerCase().replace(/[()]/g, '').replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');

export function SellProduct() {
  const navigate = useNavigate();
  const [authenticated, setAuthenticated] = useState(false);

  useEffect(() => {
    setAuthenticated(!!applyToken('user'));
  }, []);

  const { fetchProducts } = useProducts();
  // Price guide based on current market data
  const priceGuide = [
    // Grains
    { name: 'Maize (White)', category: 'Grains', price: 185, source: 'KNBS', variety: 'H614', health: 'Optimal', unit: 'kg', suggestedQty: 500 },
    { name: 'Maize (Yellow)', category: 'Grains', price: 175, source: 'KNBS', variety: 'Pioneer', health: 'Optimal', unit: 'kg', suggestedQty: 400 },
    { name: 'Rice (Basmati)', category: 'Grains', price: 240, source: 'AFA', variety: 'Mwea Pishori', health: 'High Demand', unit: 'kg', suggestedQty: 200 },
    { name: 'Wheat', category: 'Grains', price: 160, source: 'KNBS', variety: 'Narok Grade A', health: 'Stable', unit: 'kg', suggestedQty: 600 },
    
    // Vegetables
    { name: 'Sukuma Wiki (Kale)', category: 'Vegetables', price: 45, source: 'KNBS', variety: 'Thika Hybrid', health: 'Peak Season', unit: 'bunches', suggestedQty: 50 },
    { name: 'Managu (Nightshade)', category: 'Vegetables', price: 65, source: 'AFA', variety: 'Traditional', health: 'High Nutrition', unit: 'bunches', suggestedQty: 30 },
    { name: 'Spinach', category: 'Vegetables', price: 50, source: 'KNBS', variety: 'Giant Ford Hook', health: 'Optimal', unit: 'bunches', suggestedQty: 40 },
    { name: 'Cabbage', category: 'Vegetables', price: 80, source: 'KNBS', variety: 'Gloria F1', health: 'Stable', unit: 'pieces', suggestedQty: 100 },
    { name: 'Tomatoes', category: 'Vegetables', price: 120, source: 'AFA', variety: 'Anna F1', health: 'Weather Sensitive', unit: 'kg', suggestedQty: 80 },
    
    // Dairy & Meat
    { name: 'Grade A Milk (Raw)', category: 'Dairy', price: 65, source: 'KNBS', variety: 'Holstein-Friesian', health: 'Tested', unit: 'litres', suggestedQty: 100 },
    { name: 'Beef (Prime Cut)', category: 'Meat', price: 750, source: 'KNBS', variety: 'Boran Hybrid', health: 'Inspected', unit: 'kg', suggestedQty: 100 },
    
    // Poultry & Eggs
    { name: 'Indigenous Chicken (Live)', category: 'Poultry & Eggs', price: 600, source: 'KALRO', variety: 'Improved Kienyeji', health: 'Vaccinated', unit: 'whole birds', suggestedQty: 15 },
    { name: 'Broiler Chicken (Live)', category: 'Poultry & Eggs', price: 450, source: 'AFA', variety: 'Cobb 500', health: 'Ready in 6 wks', unit: 'whole birds', suggestedQty: 30 },
    { name: 'Duck (Live)', category: 'Poultry & Eggs', price: 800, source: 'KALRO', variety: 'Muscovy', health: 'Hardy Breed', unit: 'whole birds', suggestedQty: 10 },
    { name: 'Free-Range Eggs', category: 'Poultry & Eggs', price: 25, source: 'KALRO', variety: 'Kienyeji', health: 'High Omega', unit: 'trays', suggestedQty: 25 },
    { name: 'Organic Eggs', category: 'Poultry & Eggs', price: 20, source: 'AFA', variety: 'Kienyeji', health: 'Verified', unit: 'trays', suggestedQty: 20 },
    { name: 'Quail Eggs', category: 'Poultry & Eggs', price: 40, source: 'KALRO', variety: 'Japanese Quail', health: 'Nutrient Dense', unit: 'trays', suggestedQty: 15 },
    
    // Special
    { name: 'Pure Honey', category: 'Honey', price: 850, source: 'KALRO', variety: 'Acacia', health: 'Certified', unit: 'kg', suggestedQty: 10 },
    { name: 'Irish Potatoes', category: 'Tubers', price: 140, source: 'KNBS', variety: 'Shangi', health: 'High Starch', unit: 'kg', suggestedQty: 300 },
    { name: 'Sweet Potatoes', category: 'Tubers', price: 90, source: 'KALRO', variety: 'Orange Fleshed', health: 'High Vitamin A', unit: 'kg', suggestedQty: 250 }
  ];

  const [loading, setLoading] = useState(false);
  const [generating, setGenerating] = useState(false);
  const [refreshingOracle, setRefreshingOracle] = useState(false);
  const [suggestingPrice, setSuggestingPrice] = useState(false);
  const [priceSuggestion, setPriceSuggestion] = useState<{ suggestedPrice: number; source: string; confidence: number } | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [marketInsights, setMarketInsights] = useState<MarketInsights | null>(null);
  const [mapPosition, setMapPosition] = useState<{ lat: number, lng: number } | null>(null);
  const [previewImage, setPreviewImage] = useState<string | null>(null);
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    price: '',
    quantity: '',
    category: 'Vegetables',
    imageUrl: '',
    phone: '',
    location: { lat: -1.286389, lng: 36.817223, address: '' }
  });

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (ev) => {
      const img = new Image();
      img.onload = () => {
        const canvas = document.createElement('canvas');
        const MAX = 800;
        let w = img.width;
        let h = img.height;
        if (w > MAX || h > MAX) {
          const ratio = Math.min(MAX / w, MAX / h);
          w = Math.round(w * ratio);
          h = Math.round(h * ratio);
        }
        canvas.width = w;
        canvas.height = h;
        const ctx = canvas.getContext('2d');
        ctx?.drawImage(img, 0, 0, w, h);
        const compressed = canvas.toDataURL('image/jpeg', 0.7);
        setPreviewImage(compressed);
        setFormData(prev => ({ ...prev, imageUrl: compressed }));
      };
      img.src = ev.target?.result as string;
    };
    reader.readAsDataURL(file);
  };

  const handleOracleRefresh = () => {
    setRefreshingOracle(true);
    setTimeout(() => {
      setRefreshingOracle(false);
      const randomAdjustment = (Math.random() * 10 - 5).toFixed(0);
      if (formData.title) {
        const item = priceGuide.find(p => p.name === formData.title);
        if (item) {
          const newPrice = (item.price + parseInt(randomAdjustment)).toString();
          setFormData(prev => ({ ...prev, price: newPrice }));
        }
      }
    }, 1200);
  };

  const handleAISuggestPrice = async () => {
    if (!formData.title) {
      setError('Please enter a product title first.');
      return;
    }
    setSuggestingPrice(true);
    setError(null);
    try {
      const res = await api.post('/ai/suggest-price', {
        productName: formData.title,
        category: formData.category,
        recentPrices: [],
      });
      const { recommended, min, max } = res.data;
      setFormData(prev => ({ ...prev, price: String(recommended) }));
      setPriceSuggestion({ suggestedPrice: recommended, source: 'AI Model', confidence: 0.85 });
    } catch (err: any) {
      setError(err.userMessage || 'Failed to get AI price suggestion.');
    } finally {
      setSuggestingPrice(false);
    }
  };

  // AI Title Capitalization & Enhancement
  const handleTitleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = e.target.value;
    // Capitalize first letter of each word
    const capitalized = val.split(' ').map(word => word.charAt(0).toUpperCase() + word.slice(1)).join(' ');
    
    const match = priceGuide.find(p => capitalized.includes(p.name));
    if (match) {
      setFormData({ 
        ...formData, 
        title: capitalized, 
        category: match.category,
        price: match.price.toString(),
        quantity: match.suggestedQty.toString()
      });
    } else {
      setFormData({ ...formData, title: capitalized });
    }
  };

  const [searchArea, setSearchArea] = useState('');
  const [coordsInput, setCoordsInput] = useState('');
  const [privacyRadius, setPrivacyRadius] = useState(true);

  const handleSearchArea = (areaName: string) => {
    const area = NAIROBI_NEIGHBORHOODS.find(n => n.name === areaName);
    if (area) {
      const loc = { lat: area.lat, lng: area.lng };
      setMapPosition(loc);
      setFormData(prev => ({ ...prev, location: { ...prev.location, ...loc, address: areaName } }));
      setSearchArea(areaName);
      setCoordsInput(`${area.lat.toFixed(6)}, ${area.lng.toFixed(6)}`);
    }
  };

  const handleCoordsPaste = (val: string) => {
    setCoordsInput(val);
    const parts = val.split(',').map(p => parseFloat(p.trim()));
    if (parts.length === 2 && !isNaN(parts[0]) && !isNaN(parts[1])) {
      const loc = { lat: parts[0], lng: parts[1] };
      setMapPosition(loc);
      setFormData(prev => ({ ...prev, location: { ...prev.location, ...loc, address: 'Pasted Coordinates' } }));
    }
  };

  const handleUseCurrentLocation = () => {
    if ("geolocation" in navigator) {
      navigator.geolocation.getCurrentPosition((pos) => {
        const loc = { lat: pos.coords.latitude, lng: pos.coords.longitude };
        setMapPosition(loc);
        setFormData(prev => ({ ...prev, location: { ...prev.location, ...loc, address: 'Current Location' } }));
        setCoordsInput(`${loc.lat.toFixed(6)}, ${loc.lng.toFixed(6)}`);
      });
    }
  };

  // Data Integration: Fetch Market Oracle Data
  useEffect(() => {
    const fetchOracleData = async () => {
      try {
        const [prices, alerts] = await Promise.all([
          api.get('/oracle/prices?product=' + formData.category),
          api.get('/market/disruption-alerts')
        ]);
        setMarketInsights({
          recommendedPrice: prices.data?.average || 150,
          disruption: alerts.data?.active || false
        });
      } catch (e) {
        console.warn('Oracle data unavailable, using standard pricing.');
      }
    };
    if (formData.category) fetchOracleData();
  }, [formData.category]);

  const handleGenerateAI = useCallback(() => {
    if (!formData.title) {
      setError('Please enter a product title first.');
      return;
    }
    setGenerating(true);
    setTimeout(() => {
      const aiDesc = generateAIDescription(formData.title, formData.category, marketInsights);
      setFormData(prev => ({ ...prev, description: aiDesc }));
      setGenerating(false);
      setError(null);
    }, 800);
  }, [formData.title, formData.category, marketInsights]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);
    try {
      let location = formData.location;
      if (privacyRadius && location) {
        const offset = 0.0045;
        location = {
          ...location,
          lat: location.lat + (Math.random() - 0.5) * 2 * offset,
          lng: location.lng + (Math.random() - 0.5) * 2 * offset,
        };
      }
      await api.post('/products', {
        ...formData,
        location,
        price: Number(formData.price),
        quantity: Number(formData.quantity)
      });
      await fetchProducts(); // Refresh the global product state
      navigate('/market');
    } catch (err: any) {
      console.error('Failed to create product', err);
      const msg = err.response?.data?.message || err.userMessage || 'Failed to list product. Please try again.';
      setError(msg);
    } finally {
      setLoading(false);
    }
  };

  if (!authenticated) {
    return (
      <Container maxWidth="sm">
        <Box sx={{ textAlign: 'center', py: 12 }}>
          <LockOpenIcon sx={{ fontSize: 64, color: '#064e3b', mb: 3 }} />
          <Typography variant="h4" sx={{ fontWeight: 900, color: '#064e3b', mb: 2 }}>
            Sign In to List Produce
          </Typography>
          <Typography variant="body1" color="text.secondary" sx={{ mb: 4 }}>
            Sign in to start selling directly to city consumers.
          </Typography>
          <Button
            variant="contained"
            size="large"
            component={Link}
            to="/"
            sx={{ bgcolor: '#064e3b', px: 6, py: 2, borderRadius: 4, fontWeight: 800, fontSize: '1.1rem' }}
          >
            Sign In
          </Button>
          <Box sx={{ mt: 3 }}>
            <Button component={Link} to="/market" sx={{ color: '#059669', fontWeight: 600 }}>
              Browse the marketplace instead
            </Button>
          </Box>
        </Box>
      </Container>
    );
  }

  return (
    <Container maxWidth="md">
      <Box sx={{ mt: 2, mb: 6, display: 'flex', alignItems: 'center', gap: 2 }}>
        <IconButton onClick={() => navigate(-1)} sx={{ bgcolor: '#f5f5f5', flexShrink: 0 }}>
          <ArrowBackIcon />
        </IconButton>
        <Typography variant="h4" sx={{ fontWeight: 900, letterSpacing: '-0.02em', color: '#064e3b', fontSize: { xs: '1.5rem', md: '2.125rem' } }}>
          List Your Produce
        </Typography>
      </Box>

      {error && (
        <Fade in>
          <Paper sx={{ p: 2, mb: 4, bgcolor: '#fff5f5', color: '#c53030', borderRadius: 3, border: '1px solid #feb2b2', display: 'flex', alignItems: 'center', gap: 2 }}>
            <Typography variant="body2" sx={{ fontWeight: 600 }}>{error}</Typography>
          </Paper>
        </Fade>
      )}

      {marketInsights?.disruption && (
        <Fade in>
          <Alert severity="warning" icon={<WarningAmberIcon />} sx={{ mb: 4, borderRadius: 3, fontWeight: 700 }}>
            Market Notice: There are currently weather or transport delays in your area. You might want to adjust your prices.
          </Alert>
        </Fade>
      )}

      <Paper sx={{ p: { xs: 3, md: 5 }, borderRadius: 6, boxShadow: '0 20px 50px rgba(0,0,0,0.05)', border: '1px solid rgba(0,0,0,0.05)' }}>
        <Box component="form" onSubmit={handleSubmit}>
          <Grid container spacing={4}>
            <Grid item xs={12}>
              <Typography variant="subtitle2" sx={{ fontWeight: 700, mb: 1, color: '#064e3b' }}>PRODUCT DETAILS</Typography>
              <FormControl fullWidth required>
                <InputLabel>What are you selling?</InputLabel>
                <Select
                  value={formData.title}
                  label="What are you selling?"
                  onChange={(e) => {
                    const item = priceGuide.find(p => p.name === e.target.value);
                    if (item) {
                      setFormData({ 
                        ...formData, 
                        title: item.name, 
                        category: item.category,
                        price: item.price.toString(),
                        quantity: item.suggestedQty.toString()
                      });
                    }
                  }}
                  sx={{ borderRadius: 3 }}
                >
                  {priceGuide.map((item) => (
                    <MenuItem key={item.name} value={item.name}>
                      <Box sx={{ display: 'flex', justifyContent: 'space-between', width: '100%', alignItems: 'center' }}>
                        <Typography variant="body2">{item.name} - Verified {item.category}</Typography>
                        <Chip label={item.source} size="small" sx={{ height: 16, fontSize: '0.6rem', bgcolor: '#f0fdf4', color: '#059669', fontWeight: 900 }} />
                      </Box>
                    </MenuItem>
                  ))}
                </Select>
                <Typography variant="caption" sx={{ mt: 1, color: '#059669', fontWeight: 600, display: 'flex', alignItems: 'center', gap: 0.5 }}>
                  <GppGoodIcon sx={{ fontSize: 14 }} />
                  Prices updated with current market data from verified sources.
                </Typography>
              </FormControl>
            </Grid>
            <Grid item xs={12}>
              <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 1 }}>
                <Typography variant="subtitle2" sx={{ fontWeight: 700, color: '#064e3b' }}>DESCRIPTION</Typography>
                <Button 
                  size="small" 
                  startIcon={generating ? <CircularProgress size={16} color="inherit" /> : <AutoAwesomeIcon />}
                  onClick={handleGenerateAI}
                  disabled={generating}
                  sx={{ 
                    textTransform: 'none', 
                    borderRadius: 2, 
                    color: '#064e3b', 
                    fontWeight: 'bold',
                    '&:hover': { bgcolor: '#f0fdf4' }
                  }}
                >
                  {generating ? 'Writing...' : 'Help me write this'}
                </Button>
              </Box>
              <TextField
                fullWidth
                placeholder="Tell buyers about your produce. When was it harvested? How was it grown?"
                multiline
                rows={4}
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                InputProps={{ sx: { borderRadius: 3 } }}
              />
            </Grid>
            <Grid item xs={12} sm={6}>
              <Box sx={{ display: 'flex', flexDirection: { xs: 'column', sm: 'row' }, justifyContent: 'space-between', alignItems: { xs: 'flex-start', sm: 'center' }, mb: 1, gap: 1 }}>
                <Typography variant="subtitle2" sx={{ fontWeight: 700, color: '#064e3b' }}>PRICE (KES)</Typography>
                <Stack direction="row" spacing={1} sx={{ flexWrap: 'wrap', gap: 0.5 }}>
                  <Button 
                    size="small" 
                    onClick={handleAISuggestPrice}
                    disabled={suggestingPrice || !formData.title}
                    startIcon={suggestingPrice ? <CircularProgress size={14} color="inherit" /> : <AutoAwesomeIcon sx={{ fontSize: 14 }} />}
                    sx={{ textTransform: 'none', fontSize: '0.75rem', fontWeight: 700, color: '#7c3aed', whiteSpace: 'nowrap' }}
                  >
                    {suggestingPrice ? 'Thinking...' : 'AI Suggest Price'}
                  </Button>
                  <Button 
                    size="small" 
                    onClick={handleOracleRefresh}
                    disabled={refreshingOracle || !formData.title}
                    startIcon={refreshingOracle ? <CircularProgress size={14} color="inherit" /> : <RefreshIcon sx={{ fontSize: 14 }} />}
                    sx={{ textTransform: 'none', fontSize: '0.75rem', fontWeight: 700, color: '#059669', whiteSpace: 'nowrap' }}
                  >
                    {refreshingOracle ? 'Syncing...' : 'Sync Oracle'}
                  </Button>
                </Stack>
              </Box>
              <TextField
                fullWidth
                value={formData.price}
                disabled
                required
                InputProps={{ 
                  sx: { borderRadius: 3, bgcolor: '#f9fafb' },
                  startAdornment: (
                    <InputAdornment position="start">
                      <GppGoodIcon sx={{ color: '#059669', fontSize: 18 }} />
                    </InputAdornment>
                  )
                }}
                helperText={priceSuggestion ? `AI: KES ${priceSuggestion.suggestedPrice} (${priceSuggestion.source}, ${(priceSuggestion.confidence * 100).toFixed(0)}% confidence)` : 'Verified market price from KNBS and AFA data'}
              />
              {priceSuggestion && (
                <Chip
                  icon={<AutoAwesomeIcon sx={{ fontSize: 14 }} />}
                  label={`AI suggests KES ${priceSuggestion.suggestedPrice} - ${priceSuggestion.source}`}
                  size="small"
                  sx={{ mt: 1, bgcolor: '#f5f3ff', color: '#7c3aed', fontWeight: 700 }}
                />
              )}
              <PriceTruthGap slug={formData.title ? titleToSlug(formData.title) : null} />
            </Grid>
            <Grid item xs={12} sm={6}>
              <TextField
                fullWidth
                label={(() => {
                  const item = priceGuide.find(p => p.name === formData.title);
                  return item ? `How many ${item.unit}?` : 'How much do you have?';
                })()}
                type="number"
                value={formData.quantity}
                onChange={(e) => setFormData({ ...formData, quantity: e.target.value })}
                required
                helperText={formData.quantity && formData.title ? `Suggested: ${priceGuide.find(p => p.name === formData.title)?.suggestedQty ?? '-'} ${priceGuide.find(p => p.name === formData.title)?.unit ?? 'units'}` : ''}
                InputProps={{ sx: { borderRadius: 3 } }}
              />
            </Grid>
            <Grid item xs={12}>
              <FormControl fullWidth disabled>
                <InputLabel>Category</InputLabel>
                <Select
                  value={formData.category}
                  label="Category"
                  sx={{ borderRadius: 3, bgcolor: '#f9fafb' }}
                >
                  <MenuItem value="Dairy">Dairy</MenuItem>
                  <MenuItem value="Vegetables">Vegetables</MenuItem>
                  <MenuItem value="Fruits">Fruits</MenuItem>
                  <MenuItem value="Grains">Grains</MenuItem>
                  <MenuItem value="Poultry & Eggs">Poultry & Eggs</MenuItem>
                  <MenuItem value="Meat">Meat</MenuItem>
                  <MenuItem value="Tubers">Tubers</MenuItem>
                  <MenuItem value="Honey">Honey & Bee Products</MenuItem>
                  <MenuItem value="Other">Other Items</MenuItem>
                </Select>
                <Typography variant="caption" sx={{ mt: 1 }}>
                  Category is automatically assigned based on produce type.
                </Typography>
              </FormControl>
            </Grid>
            <Grid item xs={12}>
              <Divider sx={{ my: 2 }} />
              <Typography variant="subtitle2" sx={{ fontWeight: 700, mb: 1, color: '#064e3b' }}>Product photo</Typography>
              <label htmlFor="product-photo" style={{ display: 'block', cursor: 'pointer' }}>
                <Box
                  sx={{
                    border: '2px dashed',
                    borderColor: previewImage ? '#064e3b' : '#d1d5db',
                    borderRadius: 4,
                    p: 4,
                    textAlign: 'center',
                    bgcolor: previewImage ? '#f0fdf4' : '#f9fafb',
                    transition: 'all 0.2s',
                    '&:hover': { borderColor: '#064e3b', bgcolor: '#f0fdf4' }
                  }}
                >
                  {previewImage ? (
                    <>
                      <Box
                        component="img"
                        src={previewImage}
                        alt="Product preview"
                        sx={{ width: '100%', maxHeight: 300, objectFit: 'cover', borderRadius: 3, mb: 2 }}
                      />
                      <Typography sx={{ color: '#064e3b', fontWeight: 700, fontSize: '0.9rem' }}>
                        Change photo
                      </Typography>
                    </>
                  ) : (
                    <>
                      <Typography sx={{ fontSize: '2.5rem', mb: 1 }}>📷</Typography>
                      <Typography sx={{ fontWeight: 900, color: '#064e3b', mb: 0.5 }}>
                        Add product photo
                      </Typography>
                      <Typography variant="body2" color="text.secondary">
                        Take a photo or choose from gallery
                      </Typography>
                    </>
                  )}
                </Box>
              </label>
              <input
                id="product-photo"
                type="file"
                accept="image/*"
                capture="environment"
                onChange={handleImageUpload}
                style={{ display: 'none' }}
              />
            </Grid>
            <Grid item xs={12}>
              <Divider sx={{ my: 2 }} />
              <Typography variant="subtitle2" sx={{ fontWeight: 700, mb: 1, color: '#064e3b' }}>PHONE NUMBER</Typography>
              <TextField
                fullWidth
                label="Your phone number"
                placeholder="e.g. 0712345678"
                value={formData.phone}
                onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                helperText="Buyers will call or send payment to this number. Works with M-Pesa, Airtel Money, T-Kash."
                InputProps={{ sx: { borderRadius: 3 } }}
              />
            </Grid>
            <Grid item xs={12}>
              <Divider sx={{ my: 2 }} />
              <Box sx={{ display: 'flex', flexDirection: { xs: 'column', md: 'row' }, justifyContent: 'space-between', alignItems: { xs: 'stretch', md: 'center' }, mb: 2, gap: 2 }}>
                <Box>
                  <Typography variant="subtitle2" sx={{ fontWeight: 700, color: '#064e3b' }}>FARM LOCATION</Typography>
                  <Typography variant="caption" color="text.secondary">Where can buyers find your produce?</Typography>
                </Box>
                <Stack direction={{ xs: 'column', sm: 'row' }} spacing={1} alignItems={{ xs: 'stretch', sm: 'center' }}>
                  <Chip 
                    icon={<GppGoodIcon />} 
                    label={privacyRadius ? "Privacy On" : "Exact Location"} 
                    onClick={() => setPrivacyRadius(!privacyRadius)}
                    color={privacyRadius ? "success" : "default"}
                    variant={privacyRadius ? "filled" : "outlined"}
                    size="small"
                    sx={{ fontWeight: 'bold', alignSelf: { xs: 'flex-start', sm: 'auto' } }}
                  />
                  <TextField
                    select
                    size="small"
                    label="Quick Area"
                    value={searchArea}
                    onChange={(e) => handleSearchArea(e.target.value)}
                    sx={{ width: { xs: '100%', sm: 140 }, '& .MuiInputBase-root': { borderRadius: 2 } }}
                  >
                    {NAIROBI_NEIGHBORHOODS.map((option) => (
                      <MenuItem key={option.name} value={option.name}>
                        {option.name}
                      </MenuItem>
                    ))}
                  </TextField>
                  <Button 
                    size="small" 
                    variant="outlined" 
                    startIcon={<MyLocationIcon />} 
                    onClick={handleUseCurrentLocation}
                    sx={{ borderRadius: 2, textTransform: 'none', fontWeight: 'bold', color: '#064e3b', borderColor: '#064e3b', width: { xs: '100%', sm: 'auto' } }}
                  >
                    Use GPS
                  </Button>
                </Stack>
              </Box>

              <TextField
                fullWidth
                size="small"
                label="Coordinates (Optional)"
                placeholder="-1.286, 36.817"
                value={coordsInput}
                onChange={(e) => handleCoordsPaste(e.target.value)}
                sx={{ mb: 2 }}
                InputProps={{
                  startAdornment: (
                    <InputAdornment position="start">
                      <ContentPasteIcon sx={{ fontSize: 18, color: '#666' }} />
                    </InputAdornment>
                  ),
                  sx: { borderRadius: 3 }
                }}
              />

              <Box sx={{ 
                height: { xs: '300px', md: '400px' }, 
                width: '100%', 
                borderRadius: 5, 
                overflow: 'hidden', 
                border: '4px solid #f0fdf4', 
                position: 'relative',
                boxShadow: 'inset 0 2px 10px rgba(0,0,0,0.05)'
              }}>
                <MapContainer center={[-1.286389, 36.817223]} zoom={13} style={{ height: '100%', width: '100%' }}>
                  <TileLayer url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png" />
                  <LocationPicker 
                    onLocationSelect={(loc) => {
                      setFormData({ ...formData, location: { ...formData.location, ...loc } });
                      setCoordsInput(`${loc.lat.toFixed(6)}, ${loc.lng.toFixed(6)}`);
                    }} 
                    position={mapPosition} 
                    setPosition={setMapPosition} 
                    privacyMode={privacyRadius}
                  />
                </MapContainer>
              </Box>
              <Typography variant="caption" sx={{ mt: 1, display: 'block', color: 'text.secondary', fontStyle: 'italic' }}>
                {privacyRadius ? "Privacy Mode: Buyers only see your general area (500m), protecting your farm's exact spot." : "Exact location: Buyers will see exactly where you are located."}
              </Typography>
            </Grid>
            <Grid item xs={12} sx={{ mt: 2 }}>
              <Button 
                type="submit" 
                variant="contained" 
                size="large" 
                fullWidth 
                disabled={loading}
                sx={{ 
                  py: 2, 
                  bgcolor: '#064e3b', 
                  fontSize: '1.2rem',
                  fontWeight: 900,
                  borderRadius: 4,
                  boxShadow: '0 10px 30px rgba(6, 78, 59, 0.2)',
                  '&:hover': { bgcolor: '#065f46', boxShadow: '0 15px 40px rgba(6, 78, 59, 0.3)' },
                  '&:disabled': { bgcolor: '#ccc' }
                }}
              >
                {loading ? <CircularProgress size={24} color="inherit" /> : 'List My Produce Now'}
              </Button>
            </Grid>
          </Grid>
        </Box>
      </Paper>
    </Container>
  );
}
